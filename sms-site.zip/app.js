// App logic will go here later
console.log("App initialized");
